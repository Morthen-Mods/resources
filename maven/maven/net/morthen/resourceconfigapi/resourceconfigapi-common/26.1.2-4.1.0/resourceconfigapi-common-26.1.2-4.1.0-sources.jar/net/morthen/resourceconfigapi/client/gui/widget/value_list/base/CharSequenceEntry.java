package net.morthen.resourceconfigapi.client.gui.widget.value_list.base;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.morthen.resourceconfigapi.client.ClientConstants;
import net.morthen.resourceconfigapi.client.gui.screen.ResourceConfigScreen;
import net.morthen.resourceconfigapi.client.util.GuiUtils;

import java.lang.reflect.Field;
import java.util.Objects;

public abstract class CharSequenceEntry<T> extends BaseEntry {

    private final Object defaultValue;
    private final Field field;

    private final Button reset, undo;
    protected final EditBox editBox;

    public CharSequenceEntry(ResourceConfigScreen screen, String modId, String fileName, String key, Field field, Object defaultValue) {
        super(screen, modId, fileName, key, ChatFormatting.WHITE);
        this.defaultValue = defaultValue;
        this.field = field;

        reset = Button.builder(ClientConstants.RESET, button -> resetValues())
                .tooltip(GuiUtils.hasTranslation(ClientConstants.RESET_TOOLTIP) ? Tooltip.create(ClientConstants.RESET_TOOLTIP) : null)
                .bounds(0, 0, 50, 20)
                .build();

        undo = Button.builder(Component.empty(), button -> undoChanges())
                .tooltip(GuiUtils.hasTranslation(ClientConstants.UNDO_TOOLTIP) ? Tooltip.create(ClientConstants.UNDO_TOOLTIP) : null)
                .bounds(0, 0, 20, 20)
                .build();
        undo.active = false;

        editBox = new EditBox(getFont(), getWidgetWidth(), 18, Component.empty());
        editBox.setValue(getFieldValue().toString());
        editBox.setResponder(s -> undo.active = !Objects.equals(s, getFieldValue().toString()));

        this.children.add(editBox);
        this.children.add(reset);
        this.children.add(undo);
    }

    @Override
    public void extractContent(GuiGraphicsExtractor guiGraphics, int mouseX, int mouseY, boolean hovered, float delta) {
        GuiUtils.drawStringWithTooltip(this.screen, this, guiGraphics, label, tooltip, this.getContentX() + 13, this.getContentY() + 6, mouseX, mouseY);

        undo.setPosition(this.getContentX() + this.getContentWidth() - undo.getWidth() - reset.getWidth(), this.getContentY());
        reset.setPosition(this.getContentX() + this.getContentWidth() - reset.getWidth(), this.getContentY());

        editBox.setPosition(this.getContentX() + this.getContentWidth() - getWidgetWidth(), this.getContentY() + 1);
        editBox.setWidth(getWidgetWidth() - (undo.getWidth() + reset.getWidth()) - 1);

        editBox.extractRenderState(guiGraphics, mouseX, mouseY, delta);
        reset.extractRenderState(guiGraphics, mouseX, mouseY, delta);
        undo.extractRenderState(guiGraphics, mouseX, mouseY, delta);

        guiGraphics.blit(RenderPipelines.GUI_TEXTURED, undoSprite, undo.getX() + 2, undo.getY() + 2,
                0f, 0f, 16, 16, 16, 16);

        GuiUtils.renderIcon(this.screen, guiGraphics, field, this.getContentX(), this.getContentY() + 4, mouseX, mouseY);
    }

    public abstract T getValue();

    @Override
    public void undoChanges() {
        editBox.setValue(getFieldValue().toString());
        undo.active = false;
    }

    @Override
    public void resetValues() {
        editBox.setValue(defaultValue.toString());

        try {
            this.field.set(this.field, this.defaultValue);
        } catch (IllegalAccessException e) {
            throw new RuntimeException("Failed to set default value for field: " + field.getName() + "\n" + e);
        }
    }

    @Override
    public void saveValues() {
        try {
            this.field.set(field, getValue());
            undo.active = false;
        } catch (IllegalAccessException e) {
            throw new RuntimeException(String.format("Failed to save new Value for Field %s", field.getName()));
        }
    }

    protected T getFieldValue() {
        try {
            return (T) field.get(null);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(String.format("Failed to get Value for Field '%s'", field.getName()));
        }
    }
}
