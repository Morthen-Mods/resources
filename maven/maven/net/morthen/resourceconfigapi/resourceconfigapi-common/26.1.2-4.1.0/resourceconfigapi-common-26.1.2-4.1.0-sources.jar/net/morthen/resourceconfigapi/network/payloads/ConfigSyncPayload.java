package net.morthen.resourceconfigapi.network.payloads;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import net.morthen.resourceconfigapi.ConfigConstants;
import net.morthen.resourceconfigapi.api.ConfigRegistry;
import net.morthen.resourceconfigapi.config.ModConfig;

public record ConfigSyncPayload(String file, String json) implements CustomPacketPayload {
    public static final Type<ConfigSyncPayload> TYPE = ConfigConstants.type("config_sync_payload");
    public static final StreamCodec<FriendlyByteBuf, ConfigSyncPayload> CODEC =
            StreamCodec.composite(ByteBufCodecs.STRING_UTF8, ConfigSyncPayload::file,
                    ByteBufCodecs.STRING_UTF8, ConfigSyncPayload::json, ConfigSyncPayload::new);

    public static void handle(ConfigSyncPayload payload) {
        JsonObject jsonObject = JsonParser.parseString(payload.json()).getAsJsonObject();
        Identifier configLocation = Identifier.parse(payload.file());

        ConfigConstants.LOG.info("Receiving Config: {}", configLocation);
        if (ConfigRegistry.contains(configLocation)) {
            ModConfig config = ConfigRegistry.getConfig(configLocation);
            config.fromJson(jsonObject);
        }
    }

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }
}
