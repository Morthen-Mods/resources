package net.morthen.resourceconfigapi.network;

import net.minecraftforge.network.Channel;
import net.minecraftforge.network.ChannelBuilder;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.SimpleChannel;
import net.morthen.resourceconfigapi.ConfigConstants;
import net.morthen.resourceconfigapi.ResourceConfig;
import net.morthen.resourceconfigapi.network.payloads.ConfigSyncPayload;
import net.morthen.resourceconfigapi.network.payloads.ConfigUpdatePayload;

public class PayloadBuilder {
    public static void build() {
        SimpleChannel channel = ChannelBuilder.named(ConfigConstants.of("config_network"))
                .acceptedVersions(Channel.VersionTest.exact(1))
                .networkProtocolVersion(1)
                .simpleChannel();
        ResourceConfig.NETWORK = channel;

        channel.messageBuilder(ConfigSyncPayload.class, 0, NetworkDirection.PLAY_TO_CLIENT)
               .encoder((payload, byteBuf) -> ConfigSyncPayload.CODEC.encode(byteBuf, payload))
               .decoder(ConfigSyncPayload.CODEC::decode)
               .consumerNetworkThread((payload, context) -> {
                   context.enqueueWork(() -> ConfigSyncPayload.handle(payload));
               }).add();

        channel.messageBuilder(ConfigUpdatePayload.class, 1, NetworkDirection.PLAY_TO_SERVER)
               .encoder((payload, byteBuf) -> ConfigUpdatePayload.CODEC.encode(byteBuf, payload))
               .decoder(ConfigUpdatePayload.CODEC::decode)
               .consumerNetworkThread((payload, context) -> {
                   context.enqueueWork(() -> ConfigUpdatePayload.handle(payload, context.getSender().level().getServer()));
               }).add();
    }
}
